from flask import jsonify
from flask_restful import Resource, reqparse
from app.models.mission import Mission

#para adicionar
argumentos = reqparse.RequestParser()#definir os argumentos da solicitação HTTP
argumentos.add_argument('name', type=int)
argumentos.add_argument('release_date', type=int)
argumentos.add_argument('endpoint', type=int)
argumentos.add_argument('mission_state', type=int)
argumentos.add_argument('crew', type=int)
argumentos.add_argument('payload', type=int)
argumentos.add_argument('duration', type=int)
argumentos.add_argument('cost', type=int)
argumentos.add_argument('status', type=int)


#para atualizar
argumentos_update = reqparse.RequestParser() #definir os argumentos da solicitação HTTP
argumentos_update.add_argument('id', type=int)
argumentos_update.add_argument('name', type=int)
argumentos_update.add_argument('release_date', type=int)
argumentos_update.add_argument('endpoint', type=int)
argumentos_update.add_argument('mission_state', type=int)
argumentos_update.add_argument('crew', type=int)
argumentos_update.add_argument('payload', type=int)
argumentos_update.add_argument('duration', type=int)
argumentos_update.add_argument('cost', type=int)
argumentos_update.add_argument('status', type=int)

#para deletar
argumentos_delete = reqparse.RequestParser()
argumentos_delete.add_argument('id', type=int)


class Index(Resource):
    def get(self):
        return jsonify("Welcome Aplication Flask")

class MissionCreate(Resource):
    def post(self):
        try:
            datas = argumentos.parse_args()
            Mission.create_mission(self, datas['name'], datas['release_date'], datas['endpoint'], datas['mission_state'], datas['crew'], datas['payload'], datas['duration'], datas['cost'], datas['status'])
            return {"message": 'Mission create successfully!'}, 200
        except Exception as error:
            return jsonify({'status': 500, 'msg': f'{error}'}), 500

class MissionUpdate(Resource):
    def put(self):
        try:
            datas = argumentos_update.parse_args()
            Mission.update_mission(self, datas['id'], 
            datas['name'], 
            datas['release_date'], 
            datas['endpoint'], 
            datas['mission_state'], 
            datas['crew'], 
            datas['payload'], 
            datas['duration'], 
            datas['cost'], 
            datas['status']
            )
            return {"message": 'Mission update successfully!'}, 200    
        except Exception as error:
            return jsonify({'status': 500, 'msg': f'{error}'}), 500

class MissionDelete(Resource):
    def delete(self):
        try:
            datas = argumentos_delete.parse_args()
            Mission.delete_mission(self, datas['id'])
            return {"message": 'Mission delete successfully!'}, 200    
        except Exception as e:
            return jsonify({'status': 500, 'msg': f'{e}'}), 500

