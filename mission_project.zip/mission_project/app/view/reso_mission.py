from flask import jsonify
from flask_restful import Resource, reqparse
from app.models.mission import Mission

#para adicionar
argumentos = reqparse.RequestParser()#definir os argumentos da solicitação HTTP
argumentos.add_argument('name', type=str)
argumentos.add_argument('release_date', type=str)
argumentos.add_argument('endpoint', type=str)
argumentos.add_argument('mission_state', type=str)
argumentos.add_argument('crew', type=int)
argumentos.add_argument('payload', type=float)
argumentos.add_argument('duration', type=float)
argumentos.add_argument('cost', type=float)
argumentos.add_argument('status', type=str)


#para atualizar
argumentos_update = reqparse.RequestParser() #definir os argumentos da solicitação HTTP
argumentos_update.add_argument('name', type=str)
argumentos_update.add_argument('release_date', type=str)
argumentos_update.add_argument('endpoint', type=str)
argumentos_update.add_argument('mission_state', type=str)
argumentos_update.add_argument('crew', type=int)
argumentos_update.add_argument('payload', type=float)
argumentos_update.add_argument('duration', type=float)
argumentos_update.add_argument('cost', type=float)
argumentos_.add_argument('status', type=str)

#para deletar
argumento_deletar = reqparse.RequestParser()
argumento_deletar.add_argument('id', type=int)

# para Ler
#????

class Index(Resource):
    def get(self):
        return jsonify("Welcome Aplication Flask")

class MissionCreate(Resource):
    def post(self):
        try:
            datas = argumentos.parse_args()
            Mission.save_mission(self, datas['name'], datas['release_date'], datas['endpoint'], datas['mission_state'], datas['crew'], datas['payload'], datas['duration'], datas['cost'], datas['status'])
            return {"message": 'Mission create successfully!'}, 200
        except Exception as error:
            return jsonify({'status': 500, 'msg': f'{error}'}), 500

class MissionUpdate(Resource):
    def put(self):
        try:
            datas = argumentos_update.parse_args()
            Mission.update_mission(self, datas['id'], self, datas['name'], datas['release_date'], datas['endpoint'], datas['mission_state'], datas['crew'], datas['payload'], datas['duration'], datas['cost'], datas['status'])
            return {"message": 'Mission update successfully!'}, 200    
        except Exception as error:
            return jsonify({'status': 500, 'msg': f'{error}'}), 500

class MissionDelete(Resource):
    def delete(self):
        try:
            datas = argumentos_update.parse_args()
            Mission.delete_mission(self, datas['id'])
            return {"message": 'Mission delete successfully!'}, 200    
        except Exception as e:
            return jsonify({'status': 500, 'msg': f'{e}'}), 500

